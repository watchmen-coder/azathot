from setuptools import  setup

setup(
    name="bylib",
    version="1.0.0",
    description="SCRAPING WEB and MODULE DECORATIVE",
    author="@ByDog3r",
    url="https://github.com/ByDog3r",
    packages=["bylib"]
)