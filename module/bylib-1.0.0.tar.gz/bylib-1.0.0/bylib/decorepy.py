"""
___________$b__Vb.                                  
___________’$b__V$b.                                
____________$$b__V$$b.                              
____________’$$b._V$$$$oooooooo._________..
_____________’$$P*_V$$$$$”"**$$$b.____.o$$P
______________”_.oooZ$$$$b..o$$$$$$$$$$$$C          ██████╗ ██╗   ██╗██████╗  ██████╗  ██████╗ ██████╗ ██████╗ 
______________.$$$$$$$$$$$$$$$$$$$$$$$$$$$b.        ██╔══██╗╚██╗ ██╔╝██╔══██╗██╔═══██╗██╔════╝ ╚════██╗██╔══██╗
______________$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$        ██████╔╝ ╚████╔╝ ██║  ██║██║   ██║██║  ███╗ █████╔╝██████╔╝
________.o$$$o$$$$$$$$P”"*$$$$$$$$$P”"”*$$$P        ██╔══██╗  ╚██╔╝  ██║  ██║██║   ██║██║   ██║ ╚═══██╗██╔══██╗
_______.$$$**$$$$P”q$C____”$$$b________.$$P         ██████╔╝   ██║   ██████╔╝╚██████╔╝╚██████╔╝██████╔╝██║  ██║ LIBRARY
_______$$P___”$$$b__”$_._.$$$$$b.______*”           ╚═════╝    ╚═╝   ╚═════╝  ╚═════╝  ╚═════╝ ╚═════╝ ╚═╝  ╚═╝
_______$$______$$$._____”***$$$$$$$b._A.
_______V$b___._Z$$b.__._______”*$$$$$b$$:                               * Decorative Module *
________V$$.__”*$$$b.__b._________”$$$$$
_________”$$b_____”*$.__*b._________”$$$b
___________”$$b._____”L__”$$o.________”*”_____.ooo..
_____________”*$$o.________”*$$o.__________.o$$$$$
_________________”*$$b._______”$$b._______.$$$$$*”
____________________”*$$o.______”$$$o.____$$$$$’
_______________________”$$o_______”$$$b.__”$$$$__
_________________________”$b.______”$$$$b._”$$$$$
________________________._”$$_______”$$$$b__”$$$$
_________________________L.”$.______.$$$$$.__


Colors: none, red, green, blue, purple, yellow, white    signs: warning = [!], notify = [*]
up = ~, plus = [+]

"""


import os, time

try:
    import requests

except ImportError:
    print("Installing dependencies, Try again"); os.system('pip install requests')

try:
    import sys

except ImportError:
    print("Installing dependencies, Try again"); os.system('pip install sys')



class TextDecoration():

    def __init__(self):
        self.text="Sample Text"
        self.color=color['none']

    def c4c(self, text, color): # Chracter for character
        
        self.color=color
        
        for l in text:
            sys.stdout.write(self.color + l)
            sys.stdout.flush()
            time.sleep(1./12)

    def cleantext(self, text): #clean text
        pass



def clear(): # Clean Screen
    if os.name == 'nt':
      os.system('cls')
   
    else:
      os.system('clear')

# Color and text decoration

color={"none":"\033[0m", "purple":"\033[1;35m", "green":"\033[1;32m", "red":"\033[0;31m", "yellow":"\033[1;33m", "blue":"\033[0;34m", "white":"\033[1;37m"}
end="\033[0m"; green="\033[1;32m"; red="\033[0;31m"; yellow="\033[1;33m"; blue="\033[0;34m"; white="\033[1;37m"; plus=green + " [" + white + "+" + green + "] "; up=red + "    [" + green + "~" + red + "] "
signs={"warning":color["red"] + "[!] " + color["none"], "notify":color['green'] + "[" + color['blue'] + "*" + color['green'] + "] "}
plus=color['green'] + " [" + color['white'] + "+" + color['green'] + "] "; up=color['red'] + "    [" + color['green'] + "~" + color['red'] + "] "