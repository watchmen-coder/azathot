"""
___________$b__Vb.                                  
___________’$b__V$b.                                
____________$$b__V$$b.                              
____________’$$b._V$$$$oooooooo._________..
_____________’$$P*_V$$$$$”"**$$$b.____.o$$P
______________”_.oooZ$$$$b..o$$$$$$$$$$$$C          ██████╗ ██╗   ██╗██████╗  ██████╗  ██████╗ ██████╗ ██████╗ 
______________.$$$$$$$$$$$$$$$$$$$$$$$$$$$b.        ██╔══██╗╚██╗ ██╔╝██╔══██╗██╔═══██╗██╔════╝ ╚════██╗██╔══██╗
______________$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$        ██████╔╝ ╚████╔╝ ██║  ██║██║   ██║██║  ███╗ █████╔╝██████╔╝
________.o$$$o$$$$$$$$P”"*$$$$$$$$$P”"”*$$$P        ██╔══██╗  ╚██╔╝  ██║  ██║██║   ██║██║   ██║ ╚═══██╗██╔══██╗
_______.$$$**$$$$P”q$C____”$$$b________.$$P         ██████╔╝   ██║   ██████╔╝╚██████╔╝╚██████╔╝██████╔╝██║  ██║ LIBRARY
_______$$P___”$$$b__”$_._.$$$$$b.______*”           ╚═════╝    ╚═╝   ╚═════╝  ╚═════╝  ╚═════╝ ╚═════╝ ╚═╝  ╚═╝
_______$$______$$$._____”***$$$$$$$b._A.
_______V$b___._Z$$b.__._______”*$$$$$b$$:                               * HML SCRAP MODULE *
________V$$.__”*$$$b.__b._________”$$$$$
_________”$$b_____”*$.__*b._________”$$$b
___________”$$b._____”L__”$$o.________”*”_____.ooo..
_____________”*$$o.________”*$$o.__________.o$$$$$
_________________”*$$b._______”$$b._______.$$$$$*”
____________________”*$$o.______”$$$o.____$$$$$’
_______________________”$$o_______”$$$b.__”$$$$__
_________________________”$b.______”$$$$b._”$$$$$
________________________._”$$_______”$$$$b__”$$$$
_________________________L.”$.______.$$$$$.__


SCRAP: NEWS


"""



from bylib.decorepy import *

try: # Try to import requests
    import requests
except ImportError:
    print("Instalando dependencias...")
    os.system('pip install requests')

try: # Try to import Bs4
    from bs4 import BeautifulSoup
except ImportError:
    print("Instalando dependencias...")
    os.system('pip install bs4')

class Html_scrap(): 

    def __init__(self):
        self.__url = "https://github.com/ByDog3r/SVN/"
        self.__page = requests.get(self.__url)
        self.__soup = BeautifulSoup(self.__page.content, 'html.parser')
        self.__link = self.__soup.find_all(False, False)

    def news(self, url, param1, param2): # For scrap News
        self.__url = url
        self.__page = requests.get(self.__url)
        self.__soup = BeautifulSoup(self.__page.text, 'html.parser')
        self.__link = self.__soup.find_all(param1, param2)

        for i in self.__link:
            sub= i.find_all('a'); print(plus + color['yellow'] + sub[0].text + ": \n" + up + white + sub[0].attrs.get('href') + "\n" + end)